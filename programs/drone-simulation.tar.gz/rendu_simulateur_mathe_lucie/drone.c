#include <netdb.h> 
#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>
#include <stdbool.h>
#include <sys/socket.h>
#include <math.h>

#define MAX 80 
#define PORT 9000 
#define SA struct sockaddr
#define MAX_SIZE 10




void move(int* position, int* target)
{
  int xMove = target[0]-position[0];
  int yMove = target[1]-position[1];
  int zMove = target[2]-position[2];
  if (fabs(xMove) > fabs(yMove) && fabs(xMove) > fabs(zMove)) //move X
    {
      if (xMove > 0)
	position[0] += 1;
      else
	position[0] -= 1;
    }
  else if (fabs(yMove) > fabs(zMove)) //move Y
    {
      if (yMove > 0)
	position[1] += 1;
      else
	position[1] -= 1;
    }
  else
    {
      if (zMove > 0)
	position[2] += 1;
      else if (zMove < 0)
	position[2] -= 1;
    }  
      
}

    

void func(int sockfd) { 
  char buff[MAX]; 
  int n; 
  for (;;) { 
    bzero(buff, sizeof(buff)); 
    printf("Enter the string : "); 
    n = 0; 
    while ((buff[n++] = getchar()) != '\n') 
      ; 
    write(sockfd, buff, sizeof(buff)); 
    bzero(buff, sizeof(buff)); 
    read(sockfd, buff, sizeof(buff)); 
    printf("From Server : %s", buff); 
    if ((strncmp(buff, "exit", 4)) == 0) { 
      printf("Client Exit...\n"); 
      break; 
    } 
  } 
} 
  
int main() 
{ 
  int sockfd, connfd; 
  struct sockaddr_in servaddr, cli; 
  
  // socket create and varification 
  sockfd = socket(AF_INET, SOCK_STREAM, 0); 
  if (sockfd == -1) { 
    printf("socket creation failed...\n"); 
    exit(0); 
  } 
  else
    printf("Socket successfully created..\n"); 
  bzero(&servaddr, sizeof(servaddr)); 
  
  // assign IP, PORT 
  servaddr.sin_family = AF_INET; 
  servaddr.sin_addr.s_addr = inet_addr("127.0.0.1"); 
  servaddr.sin_port = htons(PORT); 
  
  // connect the client socket to server socket 
  if (connect(sockfd, (SA*)&servaddr , sizeof(servaddr)) != 0) { 
    printf("connection with the server failed...\n"); 
    exit(0); 
  } 
  else
    printf("connected to the server..\n"); 
  
  // function for chat 
  //func(sockfd); 

  write(sockfd, "D01:SRV:CONNECT\n", sizeof("D01:SRV:CONNECT\n"));

  bool connected = true;
  char *id = "D01";

  int mypos[3] = {0,0,0};
  ssize_t peer_addr_len;
  char buffer[MAX];
  int n;
     
  if((n = read(sockfd, buffer, MAX, 0)) > 0) {
    printf("%s",buffer);
    bzero(buffer,MAX);
  }
  
  char resp[MAX];
  snprintf(resp, sizeof(resp), "%s:ENV:NPS:%i:%i:%i\n", id, mypos[0], mypos[1], mypos[2]);
  printf("resp %s\n", resp);
  
  write(sockfd, resp, sizeof(resp));
     
  while (connected)
    {
      printf("Start while\n");
      char buff[MAX];
      
      if((n = read(sockfd, buff, MAX, 0)) > 0) {
	printf("%s",buff);
	
	const char separators[] = ":";
	char *msg[6];
	
	char *mess = strtok ( buff, separators );
	int i = 0;
	while (mess != NULL)
	  {
	    msg[i] = mess;
	    i++;	    
	    mess = strtok (NULL, ":");
	  }
	
	if(strcmp(&msg[0],"GCS"))
	  {
	    if (strcmp(&msg[1], id))
	      {
		printf("Message recieved from Ground control Station\n");
		if (strcmp(&msg[2],"TGT"))
		  {
		    int target[3] = {atoi(msg[3]), atoi(msg[4]), atoi(msg[5])};
		    printf("target : %i, %i, %i \n", target[0], target[1], target[2]);
		
		    move(mypos, target);
		    snprintf(resp, sizeof(resp), "%s:ENV:NPS:%i:%i:%i\n", id, mypos[0], mypos[1], mypos[2]);
		    printf(" resp : %s \n", resp);
		    
		    write(sockfd, resp, sizeof(resp));
		    sleep(1);
		    
		    snprintf(resp, sizeof(resp), "%s:SRV:DONE\n", id);
		    printf(" resp : %s \n", resp);
		    
		    write(sockfd, resp, sizeof(resp));

		  }
		else
		  printf("Message recieved, unknown action");
	      }
	      else
		printf("Message recieved for an unknown user");

	  }		
	else	if(strcmp(&msg[0],"SRV"))
	  {
	    if (strcmp(&msg[1], id))
	      {
		printf("Message recieved from Server\n");
		if (strcmp(&msg[2],"OVER"))
		  {
		    printf("This drone is dead\n");
		    close(sockfd);
		    
		  }
	      }
	  }
	else
	
	  printf("Message recieved form an unknown user %sl \n", msg[0]);
      }
      else
	printf("No recieved messr");
      
       
	      
  
    }

		// close the socket 
  close(sockfd); 
  } 
