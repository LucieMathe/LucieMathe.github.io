#include "opencv2/core/core.hpp"

#include "building.h"

Building::Building(int x, int y, int width, int length, int height) {
  this->pos = cv::Point2i(x, y);
  this->width = width;
  this->length = length;
  this->height = height;
}

Building::Building(cv::Point2i coordonates, int width, int length, int height) {
  this->pos = coordonates;
  this->width = width;
  this->length = length;
  this->height = height;
}

Building::~Building() {}

bool Building::isInside(cv::Point3i p) {
  if (p.x < this->pos.x || p.y < this->pos.y || p.z > this->height)
    return false;

  if (p.x > this->pos.x + this->length)
    return false;
  if (p.y > this->pos.y + this->width)
    return false;

  return true;
}

bool Building::intersect(Building &b) {
  for (int i = this->pos.x; i <= this->pos.x + this->length; i++)
    for (int j = this->pos.y; j <= this->pos.y + this->width; j++)
      if (b.isInside(cv::Point3i(i, j, 0)))
        return true;
  return false;
}

cv::Point2i Building::getPos() { return pos; }

int Building::getWidth() { return width; }

int Building::getLength() { return length; }

float Building::getHeight() { return height; }
