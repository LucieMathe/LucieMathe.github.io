#include "opencv2/core/core.hpp"
#include <iostream>
#include <stdio.h>

#include "env.h"

#include "building.h"
#include "drone.h"

Environnement::Environnement(int width, int length, int height,
                             std::vector<Building> buildings) {
  this->width = width;
  this->length = length;
  this->height = height;
  this->buildings = buildings;
  this->droneID = 0;
}

Environnement::~Environnement() {}

void Environnement::addDrone(Drone *drone,
                             std::vector<casesContent> *casesChanged) {
  this->drone = drone;
  this->droneID = 1;
  casesChanged->push_back(std::pair<cv::Point3i, std::vector<std::string>>(
      drone->getPos(), whatsInside(this->drone->getPos())));
}

int Environnement::getDroneID() { return this->droneID; }

std::vector<std::string> Environnement::whatsInside(cv::Point3i pos) {
  std::vector<std::string> content;
  cv::Point3i posdrone = this->drone->getPos();
  if (posdrone == pos)
    content.push_back("D01");
  for (auto b : buildings)
    if (b.isInside(pos))
      content.push_back("BLK");
  if (content.empty())
    content.push_back("EPT");
  return content;
}

void Environnement::drawEnv() {
  std::cout << "This is the environnement :" << std::endl;
  std::vector<std::string> c;

  for (int z = 0; z < height; z++) {
    for (int x = 0; x < width; x++) {
      for (int y = 0; y < length; y++) {
        c.clear();
        c = whatsInside(cv::Point3i(x, y, z));
        for (auto p : c)
          std::cout << p << ";";
      }

      std::cout << " " << std::endl;
    }
    std::cout << "up " << std::endl;
  }

  std::cout << "Over !" << std::endl;
}

void Environnement::moveDrone(cv::Point3i move, float rot,
                              std::vector<casesContent> *casesChanged) {

  std::cout << move << std::endl;

  cv::Point3i oldPos = this->drone->getPos();

  drone->translate(move);
  drone->rotate(rot);
  casesContent pair = make_pair(oldPos, whatsInside(oldPos));

  casesChanged->push_back(pair);

  casesChanged->push_back(std::pair<cv::Point3i, std::vector<std::string>>(
      drone->getPos(), whatsInside(drone->getPos())));
  //  return casesChanged;
}
