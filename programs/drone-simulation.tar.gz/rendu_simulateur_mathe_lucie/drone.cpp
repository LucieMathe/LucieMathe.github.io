#include "opencv2/core/core.hpp"
#include <iostream>

#include "drone.h"

Drone::Drone(int x, int y, int z, float dir) {
  this->pos = cv::Point3i(x, y, z);
  this->dir = dir;
}

Drone::Drone(cv::Point3i coordonates, float dir) {
  this->pos = coordonates;
  this->dir = dir;
}

Drone::Drone() {}

Drone::~Drone() {}

void Drone::translate(cv::Point3i move) { this->pos = move; }

void Drone::rotate(float move) { this->dir = move; }

cv::Point3i Drone::getPos() { return pos; }

float Drone::getDir() { return dir; }
