#include "opencv2/core/core.hpp"
#include <arpa/inet.h>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>
#define PORT 9000

#include "building.h"
#include "drone.h"
#include "env.h"

#define MAX_SIZE_BUILD 2
#define MAX_BUFF 80

int main() {
  srand(time(NULL));
  int nbBuildings = 5;
  int envWidth = 10;
  int envLength = 10;
  int envHeight = 10;

  std::vector<Building> buildings;
  for (int i = 0; i < nbBuildings; i++) {
    bool add = true;

    int width = rand() % (MAX_SIZE_BUILD - 1) + 1;
    int length = rand() % (MAX_SIZE_BUILD - 1) + 1;
    int height = rand() % envHeight + 1;

    int x = rand() % (envLength - length) + 1;
    int y = rand() % (envWidth - width) + 1;

    Building newb(x, y, width, length, height);

    for (auto b : buildings)
      if (b.intersect(newb))
        add = false;
    if (add)
      buildings.push_back(newb);
    else
      i--;
  }

  Environnement env(envWidth, envLength, envHeight, buildings);
  env.drawEnv();

  int sock = 0, valread;
  struct sockaddr_in serv_addr;
  char buffer[1024] = {0};
  if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
    printf("\n Socket creation error \n");
    return -1;
  }

  serv_addr.sin_family = AF_INET;
  serv_addr.sin_port = htons(PORT);

  // Convert IPv4 and IPv6 addresses from text to binary form
  if (inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr) <= 0) {
    printf("\nInvalid address/ Address not supported \n");
    return -1;
  }

  if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
    printf("\nConnection Failed \n");
    return -1;
  }

  send(sock, "ENV:SRV:CONNECT\n", strlen("ENV:SRV:CONNECT\n"), 0);
  char resp[MAX_BUFF];

  if ((valread = read(sock, buffer, MAX_BUFF)) > 0) {
    printf("%s", buffer);
  }
  std::vector<std::pair<cv::Point3i, std::vector<std::string>>> casesChanged;
  bool connected = true;
  cv::Point3i initDrone;
  Drone d;

  while ((env.getDroneID() == 0)) {
    char buff[MAX_BUFF];

    if ((valread = read(sock, buff, MAX_BUFF)) > 0) {
      printf("%s", buff);
      std::string message(buff, strlen(buff));

      std::vector<std::string> msg;
      std::string delimiter = ":";
      size_t pos;

      while ((pos = message.find(delimiter)) != std::string::npos) {
        msg.push_back(message.substr(0, pos));
        message.erase(0, pos + delimiter.length());
      }
      pos = message.find("\n");
      msg.push_back(message.substr(0, pos));
      if (msg[0].compare("D01") == 0) {
        printf("Message recieved from Drone 1 \n");
        if (msg[1].compare("ENV") == 0) {
          if (msg[2].compare("NPS") == 0) {
            initDrone = cv::Point3i(stoi(msg[3]), stoi(msg[4]), stoi(msg[5]));

            d = Drone(initDrone.x, initDrone.y, initDrone.z, 0);
            env.addDrone(&d, &casesChanged);
            std::cout << "create drone" << std::endl;
          }
        }
      }
    }
  }

  while (connected) {
    std::vector<std::pair<cv::Point3i, std::vector<std::string>>> casesChanged;
    char buff[MAX_BUFF];

    if ((valread = read(sock, buff, MAX_BUFF)) > 0) {
      printf("%s", buff);
      std::string message(buff, strlen(buff));

      std::vector<std::string> msg;
      std::string delimiter = ":";
      size_t pos;

      while ((pos = message.find(delimiter)) != std::string::npos) {
        msg.push_back(message.substr(0, pos));
        message.erase(0, pos + delimiter.length());
      }
      pos = message.find("\n");
      msg.push_back(message.substr(0, pos));
      int i = 0;
      if (msg[0].compare("D01") == 0) {
        printf("Message recieved from Drone 1 \n");
        if (msg[1].compare("ENV") == 0) {
          if (msg[2].compare("NPS") == 0) {

            cv::Point3i posDrone(stoi(msg[3]), stoi(msg[4]), stoi(msg[5]));
            if (env.getDroneID() == 0) {
              Drone d(posDrone.x, posDrone.y, posDrone.z, 0);
              env.addDrone(&d, &casesChanged);
              std::cout << "create drone" << std::endl;

            } else {
              env.moveDrone(posDrone, 0.0, &casesChanged);

              for (auto i : casesChanged) {
                std::string caseContent = "";
                for (std::vector<std::string>::const_iterator it =
                         i.second.begin();
                     it != i.second.end(); ++it)
                  caseContent += ":" + *it;
                caseContent += "\n";
                std::cout << caseContent << "case " << std::endl;
                char c[caseContent.size()];
                caseContent.copy(c, caseContent.size());
                snprintf(resp, sizeof(resp), "ENV:OBS:UPD:%i:%i:%i%s",
                         i.first.x, i.first.y, i.first.z, c);
                write(sock, resp, sizeof(resp));
                sleep(2);
              }

              snprintf(resp, sizeof(resp), "ENV:SRV:DONE\n");
              write(sock, resp, sizeof(resp));
            }

          } else if (msg[2].compare("ASK") == 0) {
            std::cout << "response to question" << std::endl;

            cv::Point3i posDrone(stoi(msg[3]), stoi(msg[4]), stoi(msg[5]));
            std::vector<std::string> content = env.whatsInside(posDrone);
            std::string caseContent = "";

            for (std::vector<std::string>::const_iterator it = content.begin();
                 it != content.end(); ++it)
              caseContent += ":" + *it;
            caseContent += "\n";
            std::cout << caseContent << "case " << std::endl;
            char c[caseContent.size()];
            caseContent.copy(c, caseContent.size());
            snprintf(resp, sizeof(resp), "ENV:D01:ANS%s", c);
            write(sock, resp, sizeof(resp));
          } else
            std::cout << "Message recieved, unknown action" << msg[2]
                      << std::endl;
        } else if (msg[1].compare("SRV") == 0)
          std::cout << "Message recieved for an unknown user" << msg[1]
                    << std::endl;

      } else if (msg[0].compare("SRV") == 0) {
        printf("Message recieved from Server \n");
        if (msg[1].compare("ENV") == 0) {
          if (msg[2].compare("OVER") == 0) {
            std::cout << "All drones are dead, GAME OVER" << std::endl;
            close(sock);
          }

          if (msg[2].compare("OVER\n") == 0) {
            connected = false;
          }
        }

      } else
        std::cout << "Message recieved from an unknown user " << msg[0] << "ok"
                  << std::endl;
      env.drawEnv();

    } else

      printf("No recieved messr");
  }
  close(sock);

}
