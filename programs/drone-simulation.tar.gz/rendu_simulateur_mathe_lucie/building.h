class Building {
public:
  Building(int x, int y, int width, int length, int height);
  Building(cv::Point2i coordonates, int width, int length, int height);
  ~Building();

  bool isInside(cv::Point3i);

  bool intersect(Building &b);

  cv::Point2i getPos();

  int getWidth();

  int getLength();

  float getHeight();

private:
  cv::Point2i pos;
  int width;
  int length;
  int height;
};
