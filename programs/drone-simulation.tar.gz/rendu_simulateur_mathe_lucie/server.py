import socket


# import thread module 
from _thread import *
import threading
import time


clientList = {}
gameOver =False
global droneIsAsking
global socketserver

def broadcast(message, dest):
    global gameOver
    if dest in clientList:
        if dest == "D01":
            try: 
                clientList["D01"].send(message)
            except:
                print("disconnected", dest)
                del clientList[dest]
                gameOverfun()
        if dest == "GCS":
            try: 
                clientList["GCS"].send(message)
            except:
                print("disconnected", dest)
                del clientList[dest]
                gameOverfun()
        if dest == "ENV":
            try:
                clientList["ENV"].send(message)
            except:
                print("disconnected", dest)
                del clientList[dest]
                gameOverfun()
    else:
        gameOverfun()
            
def gameOverfun():
    global socketserver
    print("over")
    for c in clientList:
        testmsg = "SRV:"+c+":OVER\n"
        try: 
            clientList[c].send(str.encode(testmsg))
            clientList[c].close()
        except:
            print("disconnected" , c)
    print("server close")
    socketserver.close()
        
def threadedGC(client):
    global isTurnOver, gameOver
    client.send(str.encode("You are connected as Ground Control Station\n"))
    while not gameOver: 
        while not isTurnOver == 0:
            time.sleep(1)
        responseFull = client.recv(255)
        if responseFull != "":
            response = responseFull.decode()
            if response == "quit":
                break
            msg = response.split(":")
            if msg[0] == "GCS" :
                if (msg[1] == "D01"):
                    broadcast(responseFull, msg[1])
                if msg[1] == "SRV" and msg[2] == "DONE\n":
                    isTurnOver += 1
            else :
                testmsg = "send a message starting by your id\n"
                broadcast(str.encode(testmsg), "GCS")
                isTurnOver = 1 + isTurnOver
            print("GC OK\n")
        
                
                    
    # connection closed 
    
    testmsg = "SRV:GCS:OVER\n"
    broadcast(str.encode(testmsg), "GCS")


    
def threadedDrone(client):
    global isTurnOver, gameOver, droneIsAsking
    client.send(str.encode("You are connected as Drone\n"))
    droneIsAsking = False
    while not gameOver:
        while ( not isTurnOver ==1) or droneIsAsking:
            time.sleep(1)
        print("reading drone")
        try: 
            responseFull = client.recv(255)
        except:
            print("disconnected")
            gameOverfun()
        if responseFull != "":
            tmp = responseFull.splitlines()
            try: 
                response = tmp[0].decode()
            except:
                print("disconnected")
                gameOverfun()
            
            print("drone", response)
            tmp = response.splitlines()
            msg = response.split(":")
            if msg[0] == "D01" :
                if (msg[1] == "ENV"):
                    if (msg[2] == "ASK"):
                        droneIsAsking = True
                    else:
                        droneIsAsking = False
                    broadcast(responseFull, msg[1])
                if msg[1] == "SRV" and msg[2] == "DONE":
                    isTurnOver += 1
            else :
                testmsg = "send a message starting by your id\n"
                client.send(str.encode(testmsg))       
                isTurnOver = 1 + isTurnOver
            print("Drone ok\n")
    # connection closed 
    testmsg = "SRV:D01:OVER\n"
    broadcast(str.encode(testmsg), "D01")
  
    
def threadedEnv(client):
    global isTurnOver, gameOver, droneIsAsking, socketserver
    client.send(str.encode("You are connected as Environnement\n"))
    droneIsAsking = False
    droneAlive = True
    while not gameOver:
        while (not isTurnOver == 2) and not droneIsAsking:
            time.sleep(1)
        print("reading env")
        responseFull = client.recv(255)
        if responseFull != "":
            tmp = responseFull.splitlines()
            print("env", tmp[0])
            response = tmp[0].decode()
            msg = response.split(":")
            if msg[0] == "ENV" :
                if (msg[1] == "D01"):
                    broadcast(responseFull, msg[1])
                    droneIsAsking = False
                
                if (msg[1] == "OBS"):
                    if len(msg) > 7:
                        if msg[6] == "D01" or msg[7] == "D01":
                            if msg[6] == "BLK" or msg[7] == "BLK":
                                droneAlive = False
                    else:
                        if msg[6] == "D01":
                            dronepos = [msg[3], msg[4], msg[5]]                                
                if (msg[1] == "SRV" and msg[2] == "DONE"):
                    if droneAlive :
                        testmsg = "OBS:GCS:D01:"+dronepos[0]+":"+dronepos[1]+":"+dronepos[2]+"\n"
                        broadcast(str.encode(testmsg), "GCS")
                    else:
                        testmsg = "OBS:GCS:D01:DEAD\n"
                        broadcast(str.encode(testmsg), "GCS")
                        gameOver= True
                    isTurnOver  = 0
                    

            else :
                testmsg = "send a message starting by your id\n"
                client.send(str.encode(testmsg))
            print("ENV OK")

    # connection closed 
    
    testmsg = "SRV:ENV:OVER\n"
    broadcast(str.encode(testmsg), "ENV")


    
if __name__ == '__main__': 
    isTurnOver= -1
    socketserver = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    socketserver.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1) 
    try:
        socketserver.bind(('localhost', 9000))
    except socketserver.error:
        print("error server")
    while not gameOver:
        if (len(clientList)==3):
            print("getting started")
            isTurnOver=0
        print("looking for client")
        socketserver.listen(5)
        client, addr = socketserver.accept()
        print ("client connected {}".format(addr))
        #print_lock.acquire() 
        print('Connected to :', addr[0], ':', addr[1])
        connectionMsg = client.recv(255)
        if connectionMsg != "":
            print(connectionMsg)
        connectionMsg = connectionMsg.decode()
        msg = connectionMsg.split(":")
        if msg[1] == "SRV":
            if msg[0] == "GCS":
                if (msg[2] == "CONNECT\n"):
                    if msg[0] in clientList :
                        print("A ground station try to join")
                        msg = "A ground station already exist you are not in the simulator\n"
                        client.send(str.encode(msg))
                    else:
                        print("started  thread GCS\n")
                        clientList["GCS"] = client
                        start_new_thread(threadedGC, (client,))
            elif msg[0] == "D01":
                tmp =  msg[2].splitlines()
                msg[2] = tmp[0]
                if (msg[2] == "CONNECT"):
                    if msg[0] in clientList :
                        print("A drone try to join")
                        msg = "A drone already exist you are not in the simulator\n"
                        client.send(str.encode(msg))
                    else:
                        print("started  thread Drone\n")
                        clientList["D01"] = client
                        start_new_thread(threadedDrone, (client,))
            elif msg[0] == "ENV":
                tmp =  msg[2].splitlines()
                msg[2] = tmp[0]
                if (msg[2] == "CONNECT"):
                    if msg[0] in clientList :
                        print("An environnement try to join")
                        msg = "An environnement already exist you are not in the simulator\n"
                        client.send(str.encode(msg))
                    else:
                        print("started  thread Env\n")
                        clientList["ENV"] = client
                        start_new_thread(threadedEnv, (client,))
            else:
                print("unknown client\n") 
        
        # Start a new thread and return its identifier 
    print ("Close")
    socketserver.close()
