class Drone {

public:
  Drone(int x, int y, int z, float dir);
  Drone(cv::Point3i coordonates, float dir);
  Drone();

  ~Drone();

  void translate(cv::Point3i move);
  void rotate(float move);
  cv::Point3i getPos();
  float getDir();

private:
  cv::Point3i pos; // x,y,z
  float dir;       // rad
};
