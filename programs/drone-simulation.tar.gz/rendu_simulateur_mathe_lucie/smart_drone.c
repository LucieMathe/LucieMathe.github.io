#include <math.h>
#include <netdb.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>

#define MAX 80
#define PORT 9000
#define SA struct sockaddr
#define MAX_SIZE 10

#define NB_DIRECTION 6
#define ENV_SIZE 10
static int N = 0;

enum Direction { NORTH = 0, SOUTH = 1, EAST = 2, WEST = 3, UP = 4, DOWN = 5 };

typedef struct Point Point;
typedef struct Case Case;

struct Point {
  int x;
  int y;
  int z;
};

struct Case {
  Point point;
  bool visited;
  bool empty;
};

bool isOutOfEnv(Point p) {
  if (p.x < 0 || p.y < 0 || p.z < 0 )
    return true;
  if (p.x >= ENV_SIZE || p.y >= ENV_SIZE || p.z >= ENV_SIZE)
    return true;
  return false;
  
}

double getDist(Point p1, Point p2) {
  if (isOutOfEnv(p1) || isOutOfEnv(p2))
    return ENV_SIZE * ENV_SIZE;

  int tmp = ((p1.x - p2.x) * (p1.x - p2.x) + (p1.y - p2.y) * (p1.y - p2.y) +
             (p1.z - p2.z) * (p1.z - p2.z));
  double toSquare = (double)tmp;

  double dist = sqrt(toSquare);
  return dist;
}

static Point DIRECTION[NB_DIRECTION]; // equivalent getDirection

Point add(Point p1, Point p2) {
  Point p;
  p.x = p1.x + p2.x;
  p.y = p1.y + p2.y;
  p.z = p1.z + p2.z;

  return p;
}

void addCase(Point p1, bool visited, bool empty, Case *cases) {
  cases[N].point.x = p1.x;
  cases[N].point.y = p1.y;
  cases[N].point.z = p1.z;
  cases[N].empty = empty;
  cases[N].visited = visited;
  N++;
}

Point getNextCase(Point position, enum Direction direction) {
  return add(position, DIRECTION[direction]);
}

int getMinIndex(double tmp[4]) {
  int indexMin = 0;
  double valueMin = tmp[0];
  for (int i = 1; i < 4; i++) {
    if (tmp[i] < valueMin) {
      indexMin = i;
      valueMin = tmp[i];
    }
  }
  return indexMin;
}

void getBestDirectionOrder(Point current_position, Point target,
                           enum Direction *order) {
  double tmp[4];
  for (int i = 0; i < 4; ++i) {
    tmp[i] = getDist(getNextCase(current_position, i), target);
  }

  for (int i = 0; i < 4; ++i) {
    int index = getMinIndex(tmp);
    order[i] = index;
    tmp[index] =
        ENV_SIZE * ENV_SIZE -
        1; //-1 because we prefer retry a pos than go in an impossible case
  }
}

int emptyCase(Point p, Case *cases) {
  for (int i = 0; i < N; ++i) {
    if (cases[i].point.x == p.x && cases[i].point.y == p.y) {
      if (cases[i].empty)
        return i;
      else
        return N;
    }
  }
  return -1;
}

Point SM(Point current_position, enum Direction *order, Case *cases) {
  int closestCase = N;
  for (int i = 0; i < 4; ++i) {
    Point nextPoint = getNextCase(current_position, order[i]);
    int result = emptyCase(nextPoint, cases);
    if (result == -1) {
      return nextPoint;
    } else if (result < closestCase) {
      closestCase = result;
    }
  }
  return cases[closestCase].point;
}

bool closestToTarget(Point current_position, Point target) {
  for (int i = 0; i < 4; ++i) {
    if (getDist(getNextCase(current_position, i), target) == 0) {
      return true;
    }
  }
  return false;
}

void initDirection() {
  for (int i = 0; i < NB_DIRECTION; i++) {
    switch (i) {
    case 0: {
      DIRECTION[i].x = -1;
      DIRECTION[i].y = 0;
      DIRECTION[i].z = 0;
      break;
    }
    case 1: {
      DIRECTION[i].x = 1;
      DIRECTION[i].y = 0;
      DIRECTION[i].z = 0;
      break;
    }
    case 2: {
      DIRECTION[i].y = 1;
      DIRECTION[i].x = 0;
      DIRECTION[i].z = 0;
      break;
    }
    case 3: {
      DIRECTION[i].y = -1;
      DIRECTION[i].x = 0;
      DIRECTION[i].z = 0;
      break;
    }
    case 4: {
      DIRECTION[i].y = 0;
      DIRECTION[i].x = 0;
      DIRECTION[i].z = 1;
      break;
    }
    case 5: {
      DIRECTION[i].y = 0;
      DIRECTION[i].x = 0;
      DIRECTION[i].z = -1;
      break;
    }
    }
  }
}

int main() {
  int sockfd, connfd;
  struct sockaddr_in servaddr, cli;

  // socket create and varification
  sockfd = socket(AF_INET, SOCK_STREAM, 0);
  if (sockfd == -1) {
    printf("socket creation failed...\n");
    exit(0);
  } else
    printf("Socket successfully created..\n");
  bzero(&servaddr, sizeof(servaddr));

  // assign IP, PORT
  servaddr.sin_family = AF_INET;
  servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
  servaddr.sin_port = htons(PORT);

  // connect the client socket to server socket
  if (connect(sockfd, (SA *)&servaddr, sizeof(servaddr)) != 0) {
    printf("connection with the server failed...\n");
    exit(0);
  } else
    printf("connected to the server..\n");

  write(sockfd, "D01:SRV:CONNECT\n", sizeof("D01:SRV:CONNECT\n"));

  bool connected = true;
  char *id = "D01";
  initDirection();

  Point current_position;
  current_position.x = 0;
  current_position.y = 0;
  current_position.z = 0;
  Point target;
  target.x = 0;
  target.y = 0;
  target.z = 0;
  Point move = current_position;
  Case cases[ENV_SIZE * ENV_SIZE];
  enum Direction best_order[4];

  /*
    int mypos[3] = {0,0,0};
    int target[3] ={0,0,0};
    int oldpos[3] = {0,0,0};
    int direction[6] = {0,0,0,0,0,0};
    bool search[6] = {false, false, false, false, false, false};
  */

  ssize_t peer_addr_len;
  char buffer[MAX];
  int n;
  bool canMove = false;
  bool turnOne = true;

  if ((n = read(sockfd, buffer, MAX, 0)) > 0) {
    printf("%s", buffer);
    bzero(buffer, MAX);
  }

  char resp[MAX];
  snprintf(resp, sizeof(resp), "%s:ENV:NPS:%i:%i:%i\n", id, current_position.x,
           current_position.y, current_position.z);
  printf("resp %s\n", resp);

  write(sockfd, resp, sizeof(resp));

  while (connected) {
    addCase(current_position, true, true, cases);
    char buff[MAX];

    if ((n = read(sockfd, buff, MAX, 0)) > 0) {

      const char separators[] = ":";
      char *msg[6];

      char *mess = strtok(buff, separators);
      int i = 0;
      while (mess != NULL) {
        msg[i] = mess;
        i++;
        mess = strtok(NULL, ":");

      }
      printf("\n");

      if (strcmp(msg[0], "ENV") == 0) {
        if (strcmp(msg[1], id) == 0) {
          printf("Message recieved from ENV\n");
          if (strcmp(msg[2], "ANS") == 0) {
            printf("%s case\n", msg[3]);

            if (strcmp(msg[3], "EPT\n") == 0 || strcmp(msg[3], "D01\n") == 0) {
              canMove = true;
            }
            else {
              addCase(move, false, false, cases);
              move = SM(current_position, best_order, cases);
              snprintf(resp, sizeof(resp), "%s:ENV:ASK:%i:%i:%i\n", id, move.x,
                       move.y, move.z);
              write(sockfd, resp, sizeof(resp));
            }
          }
        }
      } else if (strcmp(msg[0], "GCS") == 0) {
        if (strcmp(msg[1], id) == 0) {
          printf("Message recieved from Ground control Station\n");
          if (strcmp(msg[2], "TGT") == 0) {
	    if (atoi(msg[3]) != target.x || atoi(msg[4]) != target.y || atoi(msg[5]) != target.z)
	      {
		N=0;
		
		target.x = atoi(msg[3]);
		target.y = atoi(msg[4]);
		target.z = atoi(msg[5]);
	      }
	    
	    printf("target, %i, %i,%i\n", target.x, target.y, target.z);

            // first we go to the  correct floor
            if (current_position.z != target.z) {
              if (current_position.z < target.z) {
		move = getNextCase(current_position, UP);
                canMove = true;
                turnOne = false;

              } else if (turnOne) {
                turnOne = false;

                canMove = true;
              } else {
		move = getNextCase(current_position, DOWN);
		printf("move, %i, %i,%i\n", move.x, move.y, move.z);
		snprintf(resp, sizeof(resp), "%s:ENV:ASK:%i:%i:%i\n", id,
			 move.x, move.y, move.z);
		write(sockfd, resp, sizeof(resp));
	      }
            } else {
              if (turnOne) {
                turnOne = false;

                canMove = true;
              } else {
                // if we are arrive
                if (current_position.x == target.x &&
                    current_position.y == target.y)
                  canMove = true;
                else if (emptyCase(target, cases) == N &&
                         closestToTarget(current_position,
                                         target)) { // if target is a block
                  canMove = true;

                } else {
                  getBestDirectionOrder(current_position, target, best_order);
		  move = SM(current_position, best_order, cases);
                  printf("move, %i, %i,%i\n", move.x, move.y, move.z);
                  snprintf(resp, sizeof(resp), "%s:ENV:ASK:%i:%i:%i\n", id,
                           move.x, move.y, move.z);
                  write(sockfd, resp, sizeof(resp));
                }
              }
            }

          } else
            printf("Message recieved, unknown action");
        } else
          printf("Message recieved for an unknown user");

      } else if (strcmp(msg[0], "SRV") == 0) {
        if (strcmp(msg[1], id) == 0) {
          printf("Message recieved from Server\n");
          if (strcmp(msg[2], "OVER") == 0) {
            printf("This drone is dead\n");
            close(sockfd);
          }
        }
      } else

        printf("Message recieved form an unknown user %sl \n", msg[0]);

      if (canMove) {
        snprintf(resp, sizeof(resp), "%s:ENV:NPS:%i:%i:%i\n", id, move.x,
                 move.y, move.z);
        printf(" resp : %s \n", resp);
        current_position.x = move.x;
        current_position.y = move.y;
        current_position.z = move.z;

        write(sockfd, resp, sizeof(resp));
        sleep(1);
        canMove = false;

        snprintf(resp, sizeof(resp), "%s:SRV:DONE\n", id);
        printf(" resp : %s \n", resp);

        write(sockfd, resp, sizeof(resp));
      }
    }

    else
      printf("No recieved messr");
  }

  // close the socket
  close(sockfd);
}
