#pragma once

class Building;
class Drone;

class Environnement {
public:
  typedef std::pair<cv::Point3i, std::vector<std::string>> casesContent;
  Environnement(int width, int length, int height,
                std::vector<Building> buildings);
  ~Environnement();

  void addDrone(Drone *drone, std::vector<casesContent> *casesChanged);

  int getDroneID();

  std::vector<std::string> whatsInside(cv::Point3i pos);

  void moveDrone(cv::Point3i move, float rot,
                 std::vector<casesContent> *casesChanged);

  // std::vector<std::pair<cv::Point3i, std::vector<std::string>>> moveDrone(
  //   cv::Point3i move, float rot);

  void drawEnv();

  std::vector<Building> buildings;
  Drone *drone;

private:
  int width;
  int length;
  int height;
  int droneID;
};
