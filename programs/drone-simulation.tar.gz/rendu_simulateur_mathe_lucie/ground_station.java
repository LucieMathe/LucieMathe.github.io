import java.net.*;
import java.io.*;
import java.util.Scanner;



public class ground_station{

    private static final int ENV_SIZE = 10;

    public static boolean correctform(String msg)
    {
	String[] decompMsg = msg.split(":", 3);
	if (decompMsg.length < 3){
	    return false;
	}
	for (String a : decompMsg){
	    try{
		int numb = Integer.parseInt(a);
		if (numb>ENV_SIZE -1){
		    System.out.println("The environnement size is " +
				       Integer.toString(ENV_SIZE) +",");
		    System.out.println("Please your coordonates needs to be between 0 and " +
				       Integer.toString(ENV_SIZE-1) +".");
		    return false;
		}
	    }
	    catch (Exception e){
		System.out.println("Coordonates needs to be int, be careful.");
		return false;	
	    }
	}
	return true;
    }

    public static String addBeginningMessage(String msg)
    {
	return "GCS:D01:TGT:"+msg;
    }
    
    
    
    public static void main(String[] args) throws SocketException, IOException, UnknownHostException{
	Socket socket = new Socket("localhost", 9000);

	InputStream entree = socket.getInputStream();
	OutputStream sortie= socket.getOutputStream();
	Scanner sc = new Scanner(System.in);		
	String target = "";
	BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
	PrintWriter pw = new PrintWriter(socket.getOutputStream(), true);
	String msg;
	boolean targetSet = false;
	
	pw.println("GCS:SRV:CONNECT");

	//pw.println("GCS:SRV:START");
	while ((msg = br.readLine()) != null) {
	    System.out.println("Message recieved from the server :");
	    System.out.println(msg);
	    String[] arrOfStr = msg.split(":", 0);
	    if (arrOfStr[0].equals("OBS")){
		if (arrOfStr[3].equals("DEAD")){
		    System.out.println("Your drone is dead, GAME OVER");
		    pw.println("GAME OVER");

		    break;
		    
		}
	    }
	      if (arrOfStr[0].equals("SRV")){
		if (arrOfStr[2].equals("OVER")){
		    System.out.println("Your drone is dead, GAME OVER");
		    pw.println("GAME OVER");

		    break;
		    
		}
	    }
	    if (!targetSet){
		System.out.println("Please set up the drone target (x:y:z)");
		target = sc.next();
		while (!correctform(target))
		    {
			System.out.println("Please set up the drone target with requested form : x:y:z");
			target = sc.next();
		    }
		pw.println(addBeginningMessage(target));
		targetSet =true;
	    }
	    else{
		System.out.println("Actual target for the drone : " + target);
		System.out.println("Would you like to change drone destination : (yes/no)"); 
		String sendNew = sc.next();
		if (sendNew.equals("yes")){
		    System.out.println("What is the new target (x:y:z) :");
		    target = sc.next();
		    while (!correctform(target))
		    {
			System.out.println("Please set up the drone target with requested form : x:y:z :");
			target = sc.next();
		    }
		    System.out.println("New target for the drone is : " + target);
		    pw.println(addBeginningMessage(target));

		}
		else{
		    pw.println(addBeginningMessage(target));
		}
	       
	    }
	    pw.println("GCS:SRV:DONE");

	       
	    
	    if (msg.equals("quit"))
		break;   

	}
           		     		
	System.out.println("client disconnected");
	
	br.close();
	pw.close();
	socket.close();

    }
}
